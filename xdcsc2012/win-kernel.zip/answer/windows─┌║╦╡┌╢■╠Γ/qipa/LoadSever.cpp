// LoadSever.cpp: implementation of the CLoadSever class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "qipa.h"
#include "LoadSever.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLoadSever::CLoadSever()
{

}

CLoadSever::~CLoadSever()
{

}
//=================================================================
//������:StopDriver
//����:  ��ͣ����
//����:
//  IN strDriverName  ������
//  IN strServiceName ������
//����ֵ:
//  TRUE  �ɹ�
//  FALSE ʧ��
//=================================================================
BOOL CLoadSever::StopDriver(IN LPCSTR strDriverName,
    IN LPCSTR strServiceName)
{
 SC_HANDLE hMangerHandle = NULL;
 SC_HANDLE hCreateServiceHandle = NULL;
 SC_HANDLE hOpenServiceHandle = NULL;
 SERVICE_STATUS sStatus ;
 DWORD dwErrCode = 0;
 BOOL bRet = TRUE;

 do 
 {
  //1.�򿪷�����ƹ�����
  hMangerHandle = ::OpenSCManager(NULL,
   NULL,
   SC_MANAGER_ALL_ACCESS);
  if(!hMangerHandle)
  {
   bRet = FALSE;
   break;
  }
 
  //2. ��service
  hOpenServiceHandle = OpenService(hMangerHandle, strServiceName,
   SERVICE_START | DELETE | SERVICE_STOP);
  if (!hOpenServiceHandle)
  {
   dwErrCode = ::GetLastError();
   bRet = FALSE;
   break;
  }
  //4.�����������
  bRet = ControlService(hOpenServiceHandle, SERVICE_CONTROL_STOP, &sStatus);
  if (!bRet)
  {
   bRet = FALSE;
   break;
  }
  //ɾ������
  bRet = DeleteService(hOpenServiceHandle);
 
 } while (0);

 if (hOpenServiceHandle)
 {
  CloseServiceHandle(hOpenServiceHandle);
  hOpenServiceHandle = NULL;
 }
 if (hCreateServiceHandle)
 {
  CloseServiceHandle(hCreateServiceHandle);
  hCreateServiceHandle = NULL;
 }
 if (hMangerHandle)
 {
  CloseServiceHandle(hMangerHandle);
  hMangerHandle = NULL;
 }

 return bRet;
}
//��������
//=================================================================
//������:StartDriver
//����:  �Է���ķ�ʽ��������
//����:
//  IN strDriverName  ������
//  IN strServiceName ������
//  IN strDriverFilePath  �ļ�·��
//����ֵ:
//  TRUE  �ɹ�
//  FALSE ʧ��
//=================================================================
BOOL CLoadSever::StartDriver(IN LPCSTR strDriverName,
     IN LPCSTR strServiceName,
     IN LPCSTR strDriverFilePath)
{
 SC_HANDLE hMangerHandle = NULL;
 SC_HANDLE hCreateServiceHandle = NULL;
 SC_HANDLE hOpenServiceHandle = NULL;
 SERVICE_STATUS sStatus ;
 DWORD dwErrCode = 0;
 BOOL bRet = TRUE;

 do 
 {
  //1.�򿪷�����ƹ�����
  hMangerHandle = ::OpenSCManager(NULL,
          NULL,
          SC_MANAGER_ALL_ACCESS);
  if(!hMangerHandle)
  {
   bRet = FALSE;
   break;
  }
  //2. ����service
  hCreateServiceHandle = CreateService(hMangerHandle,
            strServiceName,
            strDriverName,
            SERVICE_ALL_ACCESS,
            SERVICE_KERNEL_DRIVER,//SERVICE_FILE_SYSTEM_DRIVER
            SERVICE_DEMAND_START,
            SERVICE_ERROR_IGNORE,
            strDriverFilePath,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL);
  if (!hCreateServiceHandle)
  {
   dwErrCode = ::GetLastError();
   if (ERROR_SERVICE_EXISTS != dwErrCode)
   {
    bRet = FALSE;
    break;
   }
  }

  //3. ��service
  hOpenServiceHandle = OpenService(hMangerHandle, strServiceName,
   SERVICE_START | DELETE | SERVICE_STOP);
  if (!hOpenServiceHandle)
  {
   dwErrCode = ::GetLastError();
   bRet = FALSE;
   break;
  }
  //4.�����������
  bRet = StartService(hOpenServiceHandle,NULL, NULL);
  if (FALSE == bRet)
  {
   dwErrCode = ::GetLastError();
   bRet = FALSE;
   break;
  }
 } while (0);

 if (hOpenServiceHandle)
 {
  CloseServiceHandle(hOpenServiceHandle);
  hOpenServiceHandle = NULL;
 }
 if (hCreateServiceHandle)
 {
  CloseServiceHandle(hCreateServiceHandle);
  hCreateServiceHandle = NULL;
 }
 if (hMangerHandle)
 {
  CloseServiceHandle(hMangerHandle);
  hMangerHandle = NULL;
 }
 
 return bRet;
}
