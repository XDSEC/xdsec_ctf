// qipaDlg.h : header file
//

#if !defined(AFX_QIPADLG_H__AC372F78_18AB_48BF_8CAE_4FAE83824BFA__INCLUDED_)
#define AFX_QIPADLG_H__AC372F78_18AB_48BF_8CAE_4FAE83824BFA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CQipaDlg dialog

//#define DriverName "\\??\\HelloDRIVER"
#define SeverName "hide"
#define SysPath "\\hide.sys"
class CQipaDlg : public CDialog
{
// Construction
public:
	CQipaDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CQipaDlg)
	enum { IDD = IDD_QIPA_DIALOG };
	CString	m_Tip;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQipaDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CQipaDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnStart();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	bool InstallSvc(LPTSTR lpszSvcName, LPTSTR lpszDisplayName, LPTSTR lpszSvcBinaryPath, DWORD dwSvcType, DWORD dwStartType);
	bool UnInstallSvc(LPTSTR lpszSvcName);
	bool StartSvc(LPTSTR lpszSvcName);
	bool StopSvc(LPTSTR lpszSvcName);
	DWORD  OnQuitMessage(WPARAM wParam,LPARAM lParam);
	char m_AppPath[256];
	BOOL PreTranslateMessage(MSG* pMsg);

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QIPADLG_H__AC372F78_18AB_48BF_8CAE_4FAE83824BFA__INCLUDED_)
