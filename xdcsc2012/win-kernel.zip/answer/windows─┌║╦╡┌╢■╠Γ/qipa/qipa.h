// qipa.h : main header file for the QIPA application
//

#if !defined(AFX_QIPA_H__A04E527C_8684_42DE_91CA_87D6A66E5C1C__INCLUDED_)
#define AFX_QIPA_H__A04E527C_8684_42DE_91CA_87D6A66E5C1C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CQipaApp:
// See qipa.cpp for the implementation of this class
//

#define WM_END_MESSAGE (WM_USER + 1001)
#define UniquenessGuid "0x5952002, 0xfbec, 0x4d83, 0xa7, 0x3d, 0x89, 0x48, 0x89, 0x7e, 0x4c, 0xb1"



static HANDLE g_Handle = (HANDLE)1;
class CQipaApp : public CWinApp
{
public:
	CQipaApp();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQipaApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CQipaApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QIPA_H__A04E527C_8684_42DE_91CA_87D6A66E5C1C__INCLUDED_)
