// LoadSever.h: interface for the CLoadSever class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOADSEVER_H__784F0F0F_627D_4FBA_AC3D_7ED4A7257D37__INCLUDED_)
#define AFX_LOADSEVER_H__784F0F0F_627D_4FBA_AC3D_7ED4A7257D37__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <winsvc.h>
class CLoadSever  
{
public:
	CLoadSever();
	virtual ~CLoadSever();

	static BOOL StopDriver(IN LPCSTR strDriverName,IN LPCSTR strServiceName);
	static BOOL StartDriver(
		IN LPCSTR strDriverName,
		IN LPCSTR strServiceName,
		IN LPCSTR strDriverFilePath);
};

#endif // !defined(AFX_LOADSEVER_H__784F0F0F_627D_4FBA_AC3D_7ED4A7257D37__INCLUDED_)
