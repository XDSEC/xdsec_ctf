#include <ntddk.h>
#include <devioctl.h>
#include "type.h"
#include "hook.h"
#include "hookFounction.h"
typedef struct _DEVICE_EXTENSION
{
	PDEVICE_OBJECT DeviceObject;
	UNICODE_STRING DeviceName;
	UNICODE_STRING SymbolicLink;
}DEVICE_EXTENSION,*PDEVICE_EXTENSION;

void DriverUnload(PDRIVER_OBJECT pDriverObj)
{	  
	KdPrint(("Enter  DriverUnload!\n")); 
	UnInstallSysServiceHook((ULONG)ZwQuerySystemInformation);	 
}
NTSTATUS  
DefaultDispatch (  
    __in PDEVICE_OBJECT DeviceObject,  
    __in PIRP Irp  
    )  
{  
	NTSTATUS status =STATUS_SUCCESS;
	KdPrint(("Entry DefaultDispatch"));
	return status;  
}  


NTSTATUS DriverEntry( IN PDRIVER_OBJECT DriverObject, IN PUNICODE_STRING RegistryPath )
{ 
	NTSTATUS status=STATUS_SUCCESS;
	ULONG i;
	KdPrint(("Enter DriverEntry!\n"));  

    //deal process by hyde  
    for (i = 0; i <= IRP_MJ_MAXIMUM_FUNCTION; i++)  
    {  
        DriverObject->MajorFunction[i] = DefaultDispatch;   
    }  
  
    DriverObject->DriverUnload = DriverUnload;    

	KdPrint((L"��������\n"));
	BackupSysServicesTable();
	status = InstallSysServiceHook((ULONG)ZwQuerySystemInformation,(ULONG)HookNtQuerySystemInformation);

	return status;
}

