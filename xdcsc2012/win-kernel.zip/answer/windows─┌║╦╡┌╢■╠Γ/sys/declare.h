struct _SYSTEM_THREADS
{
	LARGE_INTEGER KernelTime;
	LARGE_INTEGER CreateTime;
	ULONG WaitTime;
	PVOID StartAddress;
	CLIENT_ID Clientis;
	KPRIORITY Priority;
	KPRIORITY BasePriority;
	ULONG ContextSwitchCount;
	ULONG ThreadState;
	KWAIT_REASON WaiReason;
}SYSTEM_THREAD,*PSYSTEM_THREAD;

typedef struct _SYSTEM_PROCESS_INFORMATION 
{
 ULONG NextEntryOffset;
 ULONG NumberOfThreads;
 LARGE_INTEGER Reserved[3];
 LARGE_INTEGER CreateTime;
 LARGE_INTEGER UserTime;
 LARGE_INTEGER KernelTime;
 UNICODE_STRING ImageName;
 KPRIORITY BasePriority;
 HANDLE ProcessId;
 HANDLE InheritedFromProcessId;
 ULONG HandleCount;
 ULONG Reserved2[2];
 ULONG PrivatePageCount;
 VM_COUNTERS VirtualMemoryCounters;
 IO_COUNTERS IoCounters;
 struct _SYSTEM_THREAD Threads[0];
} SYSTEM_PROCESS_INFORMATION, *PSYSTEM_PROCESS_INFORMATION;