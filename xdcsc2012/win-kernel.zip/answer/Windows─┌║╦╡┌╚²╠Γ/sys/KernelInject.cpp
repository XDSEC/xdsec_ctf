#include "APCFunc.h"
#include "MoudleFunc.h"
#include <ntddk.h>

#define PAGEDCODE code_seg("PAGE")
#define INITCODE  code_seg("INIT")
#define MAX_PID 65535	//����ID���ֵ

//����IO������
#define IOCTL_DLLPATH CTL_CODE(\
	FILE_DEVICE_UNKNOWN,\
	0x800,\
	METHOD_BUFFERED,\
	FILE_ANY_ACCESS)

#define IOCTL_EXEPATH CTL_CODE(\
	FILE_DEVICE_UNKNOWN,\
	0x801,\
	METHOD_BUFFERED,\
	FILE_ANY_ACCESS)


//ȫ�ֱ���
PMDL pMdl = NULL;					//�ڴ���������
PVOID g_pFunctionAddress = NULL;	//ϵͳmoudle���������ĵ�ַ
char DllPath[50];					//Dll����·��
char ExePath[50];					//exe����·��

/*
InjectDll��������,�õ����������ҵ�������Ҫע��Ľ���,�õ����̺�����߳�.�������߳�
����ethread����XP..����������ϵͳ����һЩƫ�Ʋ�ͬ
*/
void InjectDll(char* DllFullPath,char* ProcessName)
{
	//ȫ������ΪULONG����
	ULONG pTargetProcess;                //Ŀ�����
	ULONG pTargetThread;                 //Ŀ���߳�
	ULONG pNotAlertableThread;           //�Ǿ����߳� 
	ULONG pSystemProcess;                //ϵͳ����
	ULONG pTempThread;                   //��ʱ�߳�
	ULONG pNextEntry, pListHead, pThNextEntry,pThListHead; 
	ULONG pid;							//����ID
	PEPROCESS EProcess;
	NTSTATUS status;

	if(!DllFullPath || !ProcessName)
	{
		KdPrint(("InjectDll: Parameters error!\n"));
		return ;
	}
	//�������̣���pid����
	for(pid=0; pid<MAX_PID; pid+=4)
	{  
		//����pid���ؽ��̵�PEPROCESS�ṹ��ָ��
		status = PsLookupProcessByProcessId((HANDLE)pid,&EProcess);
		if((NT_SUCCESS(status)))
		{
			//�ȽϽ�����
			if(_stricmp((const char*)PsGetProcessImageFileName(EProcess),(const char*)ProcessName) == 0)
			{	
				//process found!
				pSystemProcess = (ULONG)EProcess;
				pTargetProcess = pSystemProcess; 
				pTargetThread = pNotAlertableThread = 0;
				//ThreadListHead 
				//eprocess:  XP 0x190 win7 0x188 
				//kprocess:  eprocess��һ���֣�
				//ThreadListHead��ƫ��0x50 
				pThListHead = pSystemProcess+0x50;	
				pThNextEntry = *(ULONG *)pThListHead;	//next thread �ĸ��ֽ�

				//����˫������ThreadList
				while(pThNextEntry != pThListHead)
				{
					pTempThread =pThNextEntry-0x1b0;  //ETHREAD????
					//Alertable 0x164
					if(*(char *)(pTempThread+0x164)) //�����߳�
					{
						pTargetThread =pTempThread;
						DbgPrint("KernelInject -> Found alertable thread");
						break;
					}
					else
					{
						pNotAlertableThread =pTempThread;
					}

					pThNextEntry = *(ULONG *)pThNextEntry; 
				}
				break;	
			}

		}
	}

	if(!pTargetProcess){
		KdPrint(("InjectDll: Couldn't find special process!\n"));
		return ;
	}

	if(!pTargetThread)
	{
		pTargetThread = pNotAlertableThread;
	}


	if(pTargetThread)
	{
		KdPrint(("InjectDllInjectDll: Target thread: 0x%p\n", pTargetThread));
		InstallUserModeApc(DllFullPath,pTargetThread,pTargetProcess);
	}
	else
	{
		KdPrint(("InjectDll: No thread found!\n"));
	}
}

/*
һ���ں����̣��ͷ�InstallUserModeApc�з�����ڴ�
*/
void ApcKernelRoutine( IN struct _KAPC *Apc, 
	IN OUT PKNORMAL_ROUTINE *NormalRoutine, 
	IN OUT PVOID *NormalContext, 
	IN OUT PVOID *SystemArgument1, 
	IN OUT PVOID *SystemArgument2 ) 
{

	if (Apc)
		ExFreePool(Apc);
	if(pMdl)
	{
		MmUnlockPages(pMdl);
		IoFreeMdl (pMdl);
		pMdl = NULL;
	}
	KdPrint(("ApcKernelRoutine: ApcKernelRoutine called. Memory freed."));
}

/*
��ָ�����̷���APC���ڽ����л����Ժ�������Ըý���������ִ�и�APC����ע�������ΪAPC���뵽
ָ�������дӶ��ﵽring0����ring3�����ע���Ч����
�˴���ע��ring3�½����޷�����ring0�µ��ڴ棬�����Ҫ�����뼰����������ring3�ڴ��С�
*/
NTSTATUS InstallUserModeApc(const char* DllFullPath, ULONG pTargetThread, ULONG pTargetProcess)
{
	PRKAPC		pApc			= NULL; 
	KAPC_STATE	ApcState; 
	PVOID		pMappedAddress	= NULL;   //�û�̬�����ӳ���ַ
	ULONG		dwSize			= 0;	  //�û�̬�����size
	ULONG		*data_addr		= 0; 
	ULONG		dwMappedAddress = 0; 
	NTSTATUS Status = STATUS_UNSUCCESSFUL;

	if (!pTargetThread || !pTargetProcess)
		return STATUS_UNSUCCESSFUL;
	
	pApc = (PRKAPC)ExAllocatePool (NonPagedPool,sizeof (KAPC)); 
	if (!pApc)
	{
		KdPrint(("InstallUserModeApc: Failed to allocate memory for the APC structure!\n"));
		return STATUS_INSUFFICIENT_RESOURCES;
	}

	//����usercode�ĳ���in bytes
	dwSize = (unsigned char*)ApcUserCodeEnd-(unsigned char*)ApcUserCode;
	//Ϊusercode����MDL
	pMdl = IoAllocateMdl (ApcUserCode, dwSize, FALSE,FALSE,NULL);
	if (!pMdl)
	{
		KdPrint(("InstallUserModeApc: Failed to allocate MDL!\n"));
		ExFreePool (pApc);
		return STATUS_INSUFFICIENT_RESOURCES;
	}

	__try
	{
		//̽��������pMdlָ���������ڴ�ҳ���������غ�pMdlָ������ҳ
		MmProbeAndLockPages (pMdl,KernelMode,IoWriteAccess);
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		KdPrint(("InstallUserModeApc: Exception during MmProbeAndLockPages!\n"));
		IoFreeMdl (pMdl);
		ExFreePool (pApc);
		return STATUS_UNSUCCESSFUL;
	}

	//����Ŀ����̵�������
	KeStackAttachProcess((ULONG *)pTargetProcess, &ApcState);

	//��pMdlָ����������ַӳ�䵽�����ַ�����÷���ģʽΪ�û�ģʽ
	//����ӳ���ĵ�ַ
	pMappedAddress = MmMapLockedPagesSpecifyCache (pMdl, UserMode, MmCached, NULL, FALSE, NormalPagePriority);

	if (!pMappedAddress)
	{
		KdPrint(("InstallUserModeApc: Cannot map address!\n"));
		KeUnstackDetachProcess (&ApcState);
		IoFreeMdl (pMdl);
		ExFreePool (pApc);

		return STATUS_UNSUCCESSFUL;
	}
	else 
	{
		KdPrint(("InstallUserModeApc: UserMode memory at address: 0x%p\n", pMappedAddress));
	}

	dwMappedAddress = (ULONG)pMappedAddress;

	DWORD dwFunctionAddress = (DWORD)g_pFunctionAddress;
	memset ((unsigned char*)pMappedAddress + 20, 0, 300);							//����
	memcpy ((unsigned char*)pMappedAddress + 1, &dwFunctionAddress,4);				//����LoadLibraryA�����ĵ�ַ
	memcpy ((unsigned char*)pMappedAddress + 30, DllFullPath,strlen (DllFullPath)); //����DllPath��ring3

	//������������ΪDllPath�ĵ�ַ
	data_addr = (ULONG*)((char*)pMappedAddress + 9);								
	*data_addr = dwMappedAddress + 30; 

	KeUnstackDetachProcess (&ApcState); 

	//��ʼ��APC,��APC
	KeInitializeApc(pApc,
		(PETHREAD)pTargetThread,
		OriginalApcEnvironment,
		&ApcKernelRoutine,
		NULL,
		(PKNORMAL_ROUTINE)pMappedAddress,
		UserMode,
		(PVOID) NULL);
	if (!KeInsertQueueApc(pApc,0,NULL,0))
	{
		KdPrint(("KernelInject -> Failed to insert APC"));
		MmUnlockPages(pMdl);
		IoFreeMdl (pMdl);
		ExFreePool (pApc);
		return STATUS_UNSUCCESSFUL;
	}
	else
	{
		KdPrint(("APC delivered.\n"));
	}
	//ʹ�̴߳��ھ���״̬,ע�ⲻͬ����ϵͳ��ETHREAD
	if(!*(char *)(pTargetThread+0x4a))
	{
		*(char *)(pTargetThread+0x4a) = TRUE;
	}

	return 0;
}

/*
�û�̬���룬����Dll
*/
__declspec(naked) void ApcUserCode(PVOID NormalContext, PVOID  SystemArgument1, PVOID SystemArgument2)
{
	__asm 
	{		
			//ע��dll
			mov eax,0x1234			//5//������LoadLibraryA��ַ
			nop						//1
			nop						//1
			nop						//1
			push 0xabcd				//5
			call eax				//2
			jmp end					//5
			//�����洢����
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
			nop
end:
			nop
			ret 0x0c
	}

}
/*
���������û�̬����ĳ���
*/
void ApcUserCodeEnd(){}


/*
DriverUnload����
*/
#pragma PAGEDCODE
VOID Unload (IN PDRIVER_OBJECT pDriverObject) 
{	
	KdPrint(("Driver Unloaded"));
}

/*
�ַ�����
*/
NTSTATUS DeviceDispatch(IN PDEVICE_OBJECT pDevObj,
	IN PIRP pIrp)
{
	NTSTATUS Status = STATUS_SUCCESS;
	PIO_STACK_LOCATION pStack = IoGetCurrentIrpStackLocation(pIrp);
	ULONG BufLength = 0;

	//������ring3�����DllPath��ExePath
	switch(pStack->MajorFunction)
	{
	case IRP_MJ_DEVICE_CONTROL:
		switch(pStack->Parameters.DeviceIoControl.IoControlCode)
		{
			//��ȡ��ring3�����dll·��
		case IOCTL_DLLPATH:
			BufLength = pStack->Parameters.DeviceIoControl.InputBufferLength;
			RtlCopyMemory(DllPath, (char*)pIrp->AssociatedIrp.SystemBuffer, BufLength);
			KdPrint(("DllPath: %s\n", DllPath));
			break;

			//��ȡ��ring3����Ľ�����
		case IOCTL_EXEPATH:
			BufLength = pStack->Parameters.DeviceIoControl.InputBufferLength;
			RtlCopyMemory(ExePath, (char*)pIrp->AssociatedIrp.SystemBuffer, BufLength);
			KdPrint(("ExePath: %s\n", ExePath));
			//��ʼע��dll���ý�����
			InjectDll(DllPath, ExePath);
			break;

		default:
			Status = STATUS_INVALID_VARIANT;
		}

	default:
		pIrp->IoStatus.Status = Status;
		pIrp->IoStatus.Information = 0;
		IoCompleteRequest(pIrp, IO_NO_INCREMENT);
	}

	return Status;
}


/*
�������
*/
#pragma INITCODE
extern "C" NTSTATUS DriverEntry (
	IN PDRIVER_OBJECT pDriverObject,
	IN PUNICODE_STRING pRegistryPath	) 
{
	NTSTATUS		Status = STATUS_SUCCESS;
	UNICODE_STRING	DeviceName;					
	UNICODE_STRING	LinkName;
	PDEVICE_OBJECT	pDevObj;
	ULONG			i = 0;

	KdPrint(("Driver loading...\n"));


	//���÷ַ�����
	for (i = 0; i < IRP_MJ_MAXIMUM_FUNCTION; i++)
	{
		pDriverObject->MajorFunction[i] = DeviceDispatch;
	}


	//�����豸
	RtlInitUnicodeString(&DeviceName, L"\\Device\\kernel3");

	Status = IoCreateDevice(pDriverObject,
		0,
		&DeviceName,
		FILE_DEVICE_UNKNOWN,
		0,
		TRUE,
		&pDevObj);
	if(Status != STATUS_SUCCESS)
	{
		KdPrint(("DriverEntry: IoCreateDevice failed!\n"));
		return Status;
	}
	pDevObj->Flags |= DO_DIRECT_IO;


	//������������
	RtlInitUnicodeString(&LinkName, L"\\??\\kernel3");

	Status = IoCreateSymbolicLink(&LinkName, &DeviceName);
	if (Status != STATUS_SUCCESS) {
		KdPrint(("DriverEntry: IoCreateSymbolicLink failed!\n"));
		IoDeleteDevice(pDevObj);
		return Status;
	}


	//��dll�л�ȡLoadLibraryA�ĵ�ַ
	do 
	{
		UNICODE_STRING usDll;
		RtlInitUnicodeString( &usDll, L"\\SystemRoot\\system32\\kernel32.dll" );

		//����ϵͳģ��
		HANDLE hModule = LoadSystemModule( &usDll );
		if( NULL == hModule ){
			KdPrint(("DriverEntry:Load moudle error!\n"));
			break;
		}
		KdPrint(("DriverEntry:load moudle at: %x\n", hModule));

		//��ȡ����������ӳ���ַ
		g_pFunctionAddress = GetSystemProcAddress( hModule, "LoadLibraryA" );
		if( NULL == g_pFunctionAddress){
			KdPrint(("DriverEntry:get function address error!\n"));
			break;
		}
		KdPrint(("DriverEntry:get function address: %x\n", g_pFunctionAddress));

		//�ͷ�ϵͳģ��
		FreeSystemModule( hModule );

	} while( FALSE );


	pDriverObject->DriverUnload = Unload; 
	return STATUS_SUCCESS; 
}


/*
����ϵͳģ�飬ӳ�䵽���̿ռ�															
*/
HANDLE LoadSystemModule(IN PUNICODE_STRING pusModule)
{
	NTSTATUS status = STATUS_SUCCESS;
	HANDLE hFile = NULL;
	HANDLE hModule = NULL;
	HANDLE hSection = NULL;

	do 
	{
		IO_STATUS_BLOCK isb = { 0 };
		OBJECT_ATTRIBUTES oa = { 0 };
		InitializeObjectAttributes( &oa, 
			pusModule,
			OBJ_CASE_INSENSITIVE, 
			NULL, 
			NULL );

		//���ļ�
		status = ZwOpenFile( &hFile, 
			FILE_EXECUTE | SYNCHRONIZE, 
			&oa,
			&isb,
			FILE_SHARE_READ,
			FILE_SYNCHRONOUS_IO_NONALERT );
		if( !NT_SUCCESS(status) ){
			KdPrint(("LoadSystemModule:open moudle file error!\n"));
			break;
		}

		//����һ��section���󣬽���ʹ��section�����������̹������Ĳ����ڴ�ռ�
		oa.ObjectName = NULL;
		status = ZwCreateSection( &hSection,
			SECTION_ALL_ACCESS,
			&oa,
			0,
			PAGE_EXECUTE,
			SEC_IMAGE,
			hFile );
		if( !NT_SUCCESS(status) ){
			KdPrint(("LoadSystemModule:create new section error!\n"));
			break;
		}

		//ӳ��section����ͼ��Ŀ����̵������ַ�ռ�
		//view�ǽ��̿ɼ���
		DWORD dwSize = 0;
		status = ZwMapViewOfSection( hSection,
			NtCurrentProcess(),
			&hModule,
			0,
			1000,
			0,
			&dwSize,
			(SECTION_INHERIT) 1,
			MEM_TOP_DOWN,
			PAGE_READWRITE );


	} while( FALSE );

	if( NULL != hFile )
	{
		ZwClose( hFile );	//�ر��ļ����
	}

	if( NULL != hSection )
	{
		ZwClose( hSection );	//�ر�section������
	}

	if( !NT_SUCCESS(status) )
	{
		if( NULL != hModule ){
			KdPrint(("LoadSystemModule: map moudle dll error!\n"));
			ZwUnmapViewOfSection( NtCurrentProcess(), hModule );
			hModule = NULL;
		}
	}

	return hModule;
}

/*
��ȡ��������lpFunctionName�ĵ�ַ
*/
PVOID 
	GetSystemProcAddress(
	IN	HANDLE		hModule,
	IN	LPSTR		lpFunctionName
	)
{
	PVOID pFunctionAddress = NULL;

	do 
	{
		if( ( NULL == hModule ) ||
			( NULL == lpFunctionName ) )
		{
			break;
		}
		//����dll�ļ�
		PIMAGE_DOS_HEADER pDosHeader = (PIMAGE_DOS_HEADER) hModule;
		PIMAGE_OPTIONAL_HEADER pOptionalHeader = (PIMAGE_OPTIONAL_HEADER) ( (DWORD) hModule + pDosHeader->e_lfanew + 24 );
		PIMAGE_EXPORT_DIRECTORY pExportTable = (PIMAGE_EXPORT_DIRECTORY)( (DWORD) hModule + pOptionalHeader->DataDirectory[ IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress );

		PDWORD pAddressOfFunctions = (PDWORD) ( (DWORD) hModule + pExportTable->AddressOfFunctions );
		PDWORD pAddressOfNames = (PDWORD) ( (DWORD) hModule + pExportTable->AddressOfNames );
		PWORD pAddressOfNameOrdinals = (PWORD) ( (DWORD) hModule + pExportTable->AddressOfNameOrdinals );
		DWORD dwBase = pExportTable->Base;

		ANSI_STRING asFunctionName;
		RtlInitAnsiString( &asFunctionName, lpFunctionName );

		LPSTR lpExportFunctionName = NULL;
		ANSI_STRING asExportFunctionName;

		BOOL bStatus = FALSE;
		DWORD dwOrdinal = 0;
		for( DWORD dwIndex = 0; dwIndex < pExportTable->NumberOfFunctions; dwIndex ++ )
		{
			lpExportFunctionName = (LPSTR) ( (DWORD) hModule + pAddressOfNames[dwIndex] );
			RtlInitString( &asExportFunctionName, lpExportFunctionName );
			dwOrdinal = pAddressOfNameOrdinals[dwIndex] + dwBase - 1;
			pFunctionAddress = (PVOID) ( (DWORD) hModule + pAddressOfFunctions[dwOrdinal] );

			if( 0 == RtlCompareString(&asExportFunctionName, &asFunctionName, TRUE) )
			{
				bStatus = TRUE;
				break;
			}
		}

		if( !bStatus )
		{
			pFunctionAddress = NULL;
		}


	} while( FALSE );

	return pFunctionAddress;
}

/*
�ͷ�ϵͳģ��
*/
NTSTATUS
	FreeSystemModule(
	IN	HANDLE	hModule
	)
{
	NTSTATUS status = STATUS_INVALID_HANDLE;

	do 
	{
		if( NULL == hModule )
		{
			break;
		}
		//���ӳ��
		status = ZwUnmapViewOfSection( NtCurrentProcess(), hModule );


	} while( FALSE );

	return status;

}